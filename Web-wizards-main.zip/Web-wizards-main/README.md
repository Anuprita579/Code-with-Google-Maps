# Code-with-Google-Maps-2023 - Hack2skill

#### Team Name - Web Wizard
#### Problem Statement - E-Waste Facility Locator
#### Team Leader Email - 2022.anuprita.mhapankar@ves.ac.in

# A Brief of the Prototype:
Website that tells you the location of the nearest E-Waste collection and recycling facility. Offers educational pop-ups on the harmful components of your E-Waste and their effects on the environment and human health if not disposed correctly. There could be an option to input the model of your old device and earn credit points relative to the amount of precious metals recovered from the device if disposed correctly.
  
# Tech Stack: 
<img height="50" src="https://user-images.githubusercontent.com/25181517/192158954-f88b5814-d510-4564-b285-dff7d6400dad.png"> <img height="50" src="https://user-images.githubusercontent.com/25181517/183898674-75a4a1b1-f960-4ea9-abcb-637170a00a75.png"> <img height="50" src="https://user-images.githubusercontent.com/25181517/183898054-b3d693d4-dafb-4808-a509-bab54cf5de34.png"> <img height="50" src="https://user-images.githubusercontent.com/25181517/189716855-2c69ca7a-5149-4647-936d-780610911353.png"> <img height="50" src="https://user-images.githubusercontent.com/25181517/117447155-6a868a00-af3d-11eb-9cfe-245df15c9f3f.png">


# Step-by-Step Code Execution Instructions:
Here are some screenshots and videos of our working protype :

### Videos

https://github.com/Anuprita579/Web-wizards/assets/141035951/6128d692-9c39-472e-bcde-a4c3105d7af7

https://github.com/Anuprita579/Web-wizards/assets/141035951/f6b1fb0e-6e1c-4df0-92d4-14ea5618d690

https://github.com/Anuprita579/Web-wizards/assets/141035951/a0811646-de76-4905-a9b6-95ae4014d985

### Screenshots
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/ae141706-fcaa-4147-a453-dfa1524d1853)
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/49a691dc-ed75-472f-bda8-fece42e1c48a)
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/c47a033a-1e30-4067-ac7b-e5451857519f)
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/12dc098b-34d1-4f20-9d22-a975c02382eb)
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/fe4712fc-22a5-4939-bc09-cbf4bbd06d5f)
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/7cc1f52f-fa26-414a-b191-1e65ba19b0ee)
![image](https://github.com/Anuprita579/Web-wizards/assets/141035951/61760036-93a2-4f3e-9768-572605ec25d2)





# Future Scope:
The concept of Gadget-Green is not only innovative but also addresses a pressing environmental issue. As technology advances and the pace of electronic consumption increases, electronic waste (E-Waste) is becoming a significant problem. Here's a descriptive future scope for this problem statement:

* **Expanding Geographic Coverage:** Initially, Gadget-Green could focus on providing information about E-Waste collection and recycling facilities in specific regions. The future scope would involve expanding the coverage to a global scale. This means collaborating with recycling centers and organizations worldwide, making it a comprehensive international resource.
* **Mobile Application:** Developing a mobile application version of Gadget-Green to make it even more accessible. This app can provide real-time updates, notifications, and even gamify the recycling process, encouraging users to recycle more and earn rewards or recognition for their efforts.
* **Partnerships and Sponsorships:** Collaborating with electronic manufacturers, local governments, environmental organizations, and e-waste recycling companies for sponsorship and support. These partnerships can help with funding, awareness campaigns, and improving the efficiency of the E-Waste recycling process.
* **Integration with E-Commerce:** Partnering with e-commerce platforms to offer seamless recycling options when users purchase new electronics. This could be an optional feature at the checkout process where users can choose to recycle their old device through Gadget-Green.
* **Integration with Smart Devices:** In the future, Gadget-Green could integrate with smart devices to provide real-time information about the health and recycling status of electronic devices. Users could receive notifications when their devices are due for recycling or repair.
* **Interactive User Platform:** Creating an interactive community where users can share their experiences, reviews, and recommendations regarding E-Waste recycling centers. This could help other users make informed choices when selecting where to recycle their devices.
* **Corporate and Industrial Solutions:** Extending the platform to serve the needs of corporations and industries to responsibly dispose of their electronic waste. This could involve bulk recycling services and custom reporting for businesses.

Gadget-Green has the potential to grow into a comprehensive ecosystem that not only facilitates responsible E-Waste disposal but also shapes the future of electronic waste management. It can become a key player in the global efforts to reduce electronic waste's environmental and health impact

